Tinker Tank was created by Eli Rosenthal using the Pygame Library
Open the Tinker Tank folder and open "TinkerTank.exe" to play.